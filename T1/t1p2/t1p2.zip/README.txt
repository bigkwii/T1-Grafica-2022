T1P2
by: ÁLvaro Morales
rut: 20.265.040-6

I took a lot of creative liberties but technically I did what I was asked.

--- HOW TO RUN ---
type:

	python3 main.py

on terminal
or:

	python main.py

depending in how you installed it.
If you have vscode or an IDE just run main.py